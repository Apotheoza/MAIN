using SharpDX;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading.Tasks;
using Color = System.Drawing.Color;

namespace WinFormsApp1
{
    class Engine
    {
        public struct lightdata
        {
            public Svetlo svetlo;
            public Kamera kam;
            public float specularStrength;
            public Vector3 normala;
            public Vector3 wKord;
            public float shine;
            public Color boja;
            public int pozicija;

        }
        public struct Vertex
        {
            public Vector3 kord;
            public Vector3 wKord;
            public Vector3 n;
            public float X
            {
                get { return kord.X; }
                set { kord.X = value; }
            }
            public float Y
            {
                get { return kord.Y; }
                set { kord.Y = value; }
            }
            public float Z
            {
                get { return kord.Z; }
                set { kord.Z = value; }
            }
        }
        private Bitmap bmp;
        private byte[] backBuffer;
        private double[] depth;
        public float ambient;
        private int bmpWidth;
        private int bmpHeight;
        public int[,] pozicije;
        private object[] lockData;

        public Engine(Bitmap bmp)
        {
            this.bmp = bmp;
            bmpWidth = bmp.Width;
            bmpHeight = bmp.Height;
            depth = new double[bmp.Height * bmp.Width];
            backBuffer = new byte[bmpHeight * bmpWidth * 4];
            pozicije = new int[bmp.Width, bmp.Height];
            lockData = new object[bmpWidth * bmpHeight];
            for (int i = 0; i < lockData.Length; i++)
                lockData[i] = new object();
            ambient = 0.1f;
        }


        #region utility
        float Interpolate(float min, float max, float gradient)
        {
            gradient = Math.Max(0, Math.Min(gradient, 1));
            return min + (max - min) * gradient;
        }
        double Interpolate(double min, double max, double gradient)
        {
            gradient = Math.Max(0, Math.Min(gradient, 1));
            return min + (max - min) * gradient;
        }
        Vector3 Interpolate(Vector3 min, Vector3 max, float gradient)
        {
            gradient = Math.Max(0, Math.Min(gradient, 1));
            return min + (max - min) * gradient;
        }
        public void DrawEllipse(Vector3 p, Kamera camera, Color c)
        {
            var viewMatrix = Matrix.LookAtRH(camera.pozicija, camera.meta, Vector3.UnitY);
            var projectionMatrix = Matrix.PerspectiveFovRH(0.78f, (float)bmp.Width / bmp.Height, 0.1f, 1f);
            var prazna = Matrix.RotationYawPitchRoll(0, 0, 0) * Matrix.Translation(0, 0, 0);
            var praznaP = prazna * viewMatrix * projectionMatrix;
            var p1 = Project(p, praznaP);
            if (p1.X >= 0 && p1.Y >= 0 && p1.X < bmpWidth && p1.Y < bmpHeight)
            {
                /*if (p1.Z > depth[(int)p1.X + (int)p1.Y * bmpWidth])
                {
                    return;
                }*/
            }
            else return;

            using (Graphics gfx = Graphics.FromImage(bmp))
            using (SolidBrush brush = new SolidBrush(c))
            {
                gfx.FillEllipse(brush, p1.X - 10, p1.Y - 10, 20, 20);
            }
            bmp.SetPixel((int)p1.X, (int)p1.Y, Color.Blue);
        }
        public Vertex Project(Vector3 kord, Vector3 normala, Matrix transMat, Matrix worldMat)
        {
            Vertex a = new Vertex();
            a.kord = Project(kord, transMat);
            kord = Vector3.TransformCoordinate(kord, worldMat);
            normala = Vector3.TransformNormal(normala, worldMat);
            normala.Normalize();
            a.n = normala;
            a.wKord = kord;
            return a;

        }
        public Vector3 Project(Vector3 coord, Matrix transMat)
        {
            var point = Vector3.TransformCoordinate(coord, transMat);
            var x = point.X * bmpWidth + bmpWidth / 2.0f;
            var y = -point.Y * bmpHeight + bmpHeight / 2.0f;
            return (new Vector3(x, y, point.Z));
        }
        public void Clear()
        {
            for (int i = 0; i < depth.Length; i++)
            {
                depth[i] = float.MaxValue;
            }
            for (int i = 0; i < backBuffer.Length; i++)
                backBuffer[i] = 0;
            for (int i = 0; i < bmpWidth; i++)
                for (int j = 0; j < bmpHeight; j++)
                    pozicije[i, j] = -1;
        }
        public bool Cull(Vector3 t1, Vector3 t2, Vector3 t3)
        {
            t2 -= t1;
            t3 -= t1;
            Vector3 n = new Vector3(t2.Y * t3.Z - t2.Z * t3.Y, t2.Z * t3.X - t2.X * t3.Z, t2.X * t3.Y - t2.Y * t3.X);
            if (Vector3.Dot(n, t1) >= 0)
                return false;
            return true;
        }
        public void PutPixel(int i, Color color)
        {
            backBuffer[i] = color.B;
            backBuffer[i + 1] = color.G;
            backBuffer[i + 2] = color.R;
            backBuffer[i + 3] = 255;
        }
        public void Flush()
        {
            BitmapData bData = bmp.LockBits(new System.Drawing.Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, bmp.PixelFormat);
            System.Runtime.InteropServices.Marshal.Copy(backBuffer, 0, bData.Scan0, backBuffer.Length);
            bmp.UnlockBits(bData);
        }

        #endregion
        #region internet
        public Color Shader(lightdata data)
        {
            var viewDir = data.kam.pozicija - data.wKord;
            if (viewDir.LengthSquared() > 0)
                viewDir.Normalize();
            var smer = data.wKord - data.svetlo.poz;
            if (smer.LengthSquared() > 0)
                smer.Normalize();
            var reflection = smer - 2 * (Vector3.Dot(smer, data.normala) * data.normala);
            if (reflection.LengthSquared() > 0)
                reflection.Normalize();
            float spec = (float)(Math.Pow(Math.Max(Vector3.Dot(viewDir, reflection), 0), data.shine));
            var diff = Math.Max(0, Vector3.Dot(-smer, data.normala));
            var i1 = spec * data.specularStrength + diff + ambient;
            Vector3 i = new Vector3(ambient + (diff + spec) * ((float)data.svetlo.boja.R / 255), ambient + (diff + spec) * ((float)data.svetlo.boja.G / 255), ambient + (diff + spec) * ((float)data.svetlo.boja.B / 255));
            int r = Math.Clamp((int)(data.boja.R * i.X), 0, 255);
            int g = Math.Clamp((int)(data.boja.G * i.Y), 0, 255);
            int b = Math.Clamp((int)(data.boja.B * i.Z), 0, 255);
            return Color.FromArgb(r, g, b);
        }
        public void DrawPoint(float x, float y, double z, lightdata data)
        {
            if (x >= 0 && y >= 0 && x < bmpWidth && y < bmpHeight)
            {
                int index = (int)x + (int)y * bmpWidth;
                lock (lockData[index])
                {
                    if (z < depth[index])
                    {
                        pozicije[(int)x, (int)y] = data.pozicija;
                        Color clr = Shader(data);
                        depth[index] = z;
                        PutPixel(index * 4, clr);
                    }
                }
            }
        }

        void scanline(int y, Vertex pa, Vertex pb, Vertex pc, Vertex pd, lightdata data)
        {
            var gradient1 = pa.Y != pb.Y ? (y - pa.Y) / (pb.Y - pa.Y) : 1;
            var gradient2 = pc.Y != pd.Y ? (y - pc.Y) / (pd.Y - pc.Y) : 1;
            int sx = (int)Interpolate(pa.X, pb.X, gradient1);
            int ex = (int)Interpolate(pc.X, pd.X, gradient2);
            if (ex <= sx) return;

            data.normala = Interpolate(pa.n, pb.n, gradient1);
            Vector3 en = Interpolate(pc.n, pd.n, gradient2);
            data.wKord = Interpolate(pa.wKord, pb.wKord, gradient1);
            Vector3 ewkord = Interpolate(pc.wKord, pd.wKord, gradient2);

            double sz = Interpolate(pa.Z, pb.Z, gradient1);
            double ez = Interpolate(pc.Z, pd.Z, gradient2);
            float deltaGrad = 1 / (float)(ex - sx);
            var ndelta = deltaGrad * (en - data.normala);
            var wkordDelta = deltaGrad * (ewkord - data.wKord);
            var zDelta = deltaGrad * (ez - sz);
            for (var x = sx; x < ex; x++)
            {
                DrawPoint(x, y, sz, data);
                sz += zDelta;
                data.wKord += wkordDelta;
                data.normala += ndelta;
                if (data.normala.LengthSquared() > 0)
                    data.normala.Normalize();
            }
        }
        public void DrawTriangle(Vertex p1, Vertex p2, Vertex p3, lightdata data)
        {
            #region sort
            if (p1.Y > p2.Y)
            {
                var temp = p2;
                p2 = p1;
                p1 = temp;
            }

            if (p2.Y > p3.Y)
            {
                var temp = p2;
                p2 = p3;
                p3 = temp;
            }

            if (p1.Y > p2.Y)
            {
                var temp = p2;
                p2 = p1;
                p1 = temp;
            }
            float dP1P2, dP1P3;
            if (p2.Y - p1.Y > 0)
                dP1P2 = (p2.X - p1.X) / (p2.Y - p1.Y);
            else
                dP1P2 = p1.X < p2.X ? float.MaxValue : float.MinValue;

            if (p3.Y - p1.Y > 0)
                dP1P3 = (p3.X - p1.X) / (p3.Y - p1.Y);
            else
                dP1P3 = 0;
            #endregion
            if (dP1P2 > dP1P3)
            {
                for (var y = (int)p1.Y; y <= (int)p3.Y; y++)
                {
                    if (y < p2.Y)
                    {
                        scanline(y, p1, p3, p1, p2, data);
                    }
                    else
                    {
                        scanline(y, p1, p3, p2, p3, data);
                    }
                }
            }
            else
            {
                for (var y = (int)p1.Y; y <= (int)p3.Y; y++)
                {
                    if (y < p2.Y)
                    {
                        scanline(y, p1, p2, p1, p3, data);
                    }
                    else
                    {
                        scanline(y, p2, p3, p1, p3, data);
                    }
                }
            }
        }
        #endregion



        public void Crtaj(Kamera camera, Svetlo svetlo, int ij, params Objekat[] meshes)
        {
            var viewMatrix = Matrix.LookAtRH(camera.pozicija, camera.meta, Vector3.UnitY);
            var projectionMatrix = Matrix.PerspectiveFovRH(0.78f, (float)bmp.Width / bmp.Height, 0.1f, 1f);
            foreach (Objekat mesh in meshes)
            {
                if (mesh == null || mesh.tackice == null || mesh.lica == null)
                    continue;

                lightdata data = new lightdata();
                data.svetlo = svetlo;
                data.kam = camera;
                data.specularStrength = mesh.shineS;
                data.shine = mesh.shine;
                data.pozicija = ij;
                data.boja = mesh.Boja;
                var worldMatrix = Matrix.RotationYawPitchRoll(mesh.rotacija.Y, mesh.rotacija.X, mesh.rotacija.Z) * Matrix.Translation(mesh.pozicija);
                var transMat = worldMatrix * viewMatrix * projectionMatrix;

                Parallel.For(0, mesh.lica.Length, i =>
                {
                    var lice = mesh.lica[i];
                    if (lice.t1 < 0 || lice.t1 >= mesh.tackice.Length ||
                        lice.t2 < 0 || lice.t2 >= mesh.tackice.Length ||
                        lice.t3 < 0 || lice.t3 >= mesh.tackice.Length)
                        return;

                    Vector3 n1 = (mesh.normale != null && lice.n1 >= 0 && lice.n1 < mesh.normale.Length) ? mesh.normale[lice.n1] : Vector3.UnitY;
                    Vector3 n2 = (mesh.normale != null && lice.n2 >= 0 && lice.n2 < mesh.normale.Length) ? mesh.normale[lice.n2] : Vector3.UnitY;
                    Vector3 n3 = (mesh.normale != null && lice.n3 >= 0 && lice.n3 < mesh.normale.Length) ? mesh.normale[lice.n3] : Vector3.UnitY;

                    var p1 = Project(mesh.tackice[lice.t1], n1, transMat, worldMatrix);
                    var p2 = Project(mesh.tackice[lice.t2], n2, transMat, worldMatrix);
                    var p3 = Project(mesh.tackice[lice.t3], n3, transMat, worldMatrix);

                    lightdata threadData = data;
                    if (Cull(p1.kord, p2.kord, p3.kord))
                    {
                        DrawTriangle(p1, p2, p3, threadData);
                    }
                });
            }
        }
        public void Crtaj(Kamera camera, Svetlo svetlo, params Objekat[] meshes)
        {
            var viewMatrix = Matrix.LookAtRH(camera.pozicija, camera.meta, Vector3.UnitY);
            var projectionMatrix = Matrix.PerspectiveFovRH(0.78f, (float)bmp.Width / bmp.Height, 0.1f, 1f);
            foreach (Objekat mesh in meshes)
            {
                if (mesh == null || mesh.tackice == null || mesh.lica == null)
                    continue;

                lightdata data = new lightdata();
                data.svetlo = svetlo;
                data.kam = camera;
                data.specularStrength = mesh.shineS;
                data.shine = mesh.shine;
                data.pozicija = -1;
                data.boja = mesh.Boja;

                var worldMatrix = Matrix.RotationYawPitchRoll(mesh.rotacija.Y, mesh.rotacija.X, mesh.rotacija.Z) * Matrix.Translation(mesh.pozicija);
                var transMat = worldMatrix * viewMatrix * projectionMatrix;

                Parallel.For(0, mesh.lica.Length, i =>
                {
                    var lice = mesh.lica[i];
                    if (lice.t1 < 0 || lice.t1 >= mesh.tackice.Length ||
                        lice.t2 < 0 || lice.t2 >= mesh.tackice.Length ||
                        lice.t3 < 0 || lice.t3 >= mesh.tackice.Length)
                        return;

                    Vector3 n1 = (mesh.normale != null && lice.n1 >= 0 && lice.n1 < mesh.normale.Length) ? mesh.normale[lice.n1] : Vector3.UnitY;
                    Vector3 n2 = (mesh.normale != null && lice.n2 >= 0 && lice.n2 < mesh.normale.Length) ? mesh.normale[lice.n2] : Vector3.UnitY;
                    Vector3 n3 = (mesh.normale != null && lice.n3 >= 0 && lice.n3 < mesh.normale.Length) ? mesh.normale[lice.n3] : Vector3.UnitY;

                    var p1 = Project(mesh.tackice[lice.t1], n1, transMat, worldMatrix);
                    var p2 = Project(mesh.tackice[lice.t2], n2, transMat, worldMatrix);
                    var p3 = Project(mesh.tackice[lice.t3], n3, transMat, worldMatrix);

                    lightdata threadData = data;
                    if (Cull(p1.kord, p2.kord, p3.kord))
                    {
                        DrawTriangle(p1, p2, p3, threadData);
                    }
                });
            }
        }
    }
}
