using SharpDX;
using System.Collections.Generic;
using System.IO;
using Color = System.Drawing.Color;
namespace WinFormsApp1

{
    public class Lice
    {
        public int t1;
        public int t2;
        public int t3;
        public int n1;
        public int n2;
        public int n3;

        public Lice(int x, int y, int z)
        {
            t1 = x;
            t2 = y;
            t3 = z;
        }
        public Lice(int t1, int t2, int t3, int n1, int n2, int n3)
        {
            this.t1 = t1;
            this.t2 = t2;
            this.t3 = t3;
            this.n1 = n1;
            this.n2 = n2;
            this.n3 = n3;
        }
    }
    public class Objekat
    {
        bool saTri = false;

        public string ime { get; set; }

        public bool SaTri
        {
            get
            {
                return saTri;
            }
        }

        public float shine;

        public float shineS;


        public System.Drawing.Color Boja
        {
            get; set;
        }

        public Vector3[] tackice { get; set; }
        public int brtackica { get; set; }
        public Lice[] lica { get; private set; }
        public Vector3[] normale { get; private set; }
        public Vector3 pozicija { get; set; }
        public Vector3 rotacija { get; set; }
        public Objekat(string ime)
        {
            /*            tackice = new List<Vector3>();
                        lica = new List<Lice>();
                        normale = new List<Vector3>();*/
            this.ime = ime;
        }
        public Objekat(string ime, int brtackica, int brnormala, int brlica)
        {
            tackice = new Vector3[brtackica];
            lica = new Lice[brlica];
            normale = new Vector3[brnormala];
            pozicija = Vector3.Zero;
            rotacija = Vector3.Zero;
            this.ime = ime;
        }
        public void SetN(Objekat obj)
        {
            List<Vector3> norm = new List<Vector3>();
            Vector3[] normT;
            normT = new Vector3[obj.tackice.Length];
            foreach (Lice lice in lica)
            {
                var t1 = tackice[lice.t1];
                var t2 = tackice[lice.t2];
                var t3 = tackice[lice.t3];
                t2 -= t1;
                t3 -= t1;
                Vector3 n = new Vector3(t2.Y * t3.Z - t2.Z * t3.Y, t2.Z * t3.X - t2.X * t3.Z, t2.X * t3.Y - t2.Y * t3.X);
                norm.Add(n);
            }
            for (int i = 0; i < lica.Length; i++)
            {
                normT[lica[i].t1] += norm[i];
                normT[lica[i].t2] += norm[i];
                normT[lica[i].t3] += norm[i];
            }
            for (int i = 0; i < normT.Length; i++)
            {
                if (normT[i].LengthSquared() > 0)
                    normT[i].Normalize();
            }
            normale = normT;
            for (int i = 0; i < lica.Length; i++)
            {
                lica[i].n1 = lica[i].t1;
                lica[i].n2 = lica[i].t2;
                lica[i].n3 = lica[i].t3;
            }
        }


        public static List<Objekat> UcitajIzFajla(string put)
        {
            if (string.IsNullOrEmpty(put))
                return new List<Objekat>();

            string path = put;
            if (!File.Exists(path))
            {
                string baseDir = System.AppDomain.CurrentDomain.BaseDirectory;
                string candidate = Path.Combine(baseDir, put);
                if (File.Exists(candidate))
                    path = candidate;
                else
                {
                    candidate = Path.Combine(baseDir, "..", "..", "..", put);
                    if (File.Exists(candidate))
                        path = candidate;
                }
            }

            if (!File.Exists(path))
                return new List<Objekat>();

            using (StreamReader reader = new StreamReader(path))
            {
                return UcitajIzFajla(reader, Path.GetFileNameWithoutExtension(path));
            }
        }

        public static List<Objekat> UcitajIzFajla(StreamReader reader, string defaultName = "obj")
        {
            if (reader == null)
                return new List<Objekat>();
            List<Objekat> fensiLista = new List<Objekat>();
            List<Vector3> normale = new List<Vector3>();
            List<Vector3> tackice = new List<Vector3>();
            List<Lice> lica = new List<Lice>();
            Objekat curr = null;
            while (!reader.EndOfStream)
            {
                string s = reader.ReadLine();
                if (string.IsNullOrWhiteSpace(s))
                    continue;
                s = s.Trim();
                if (s.StartsWith("#"))
                    continue;

                if (s.StartsWith("g ") || s == "g")
                {
                    if (curr != null)
                    {
                        curr.tackice = tackice.ToArray();
                        curr.normale = normale.ToArray();
                        curr.lica = lica.ToArray();
                    }
                    tackice.Clear();
                    normale.Clear();
                    lica.Clear();
                    string[] parts = s.Split(new[] { ' ' }, System.StringSplitOptions.RemoveEmptyEntries);
                    curr = new Objekat(parts.Length > 1 ? parts[1] : defaultName);
                    fensiLista.Add(curr);
                    continue;
                }
                if (curr == null)
                {
                    curr = new Objekat(defaultName);
                    fensiLista.Add(curr);
                }
                if (s.StartsWith("vn"))
                {
                    string[] b = s.Split(new[] { ' ' }, System.StringSplitOptions.RemoveEmptyEntries);
                    if (b.Length >= 4 &&
                        float.TryParse(b[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float nx) &&
                        float.TryParse(b[2], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float ny) &&
                        float.TryParse(b[3], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float nz))
                    {
                        normale.Add(new Vector3(nx, ny, nz));
                    }
                    continue;
                }
                if (s.StartsWith("vt"))
                {
                    continue;
                }
                if (s.StartsWith("v ") || s.StartsWith("v\t"))
                {
                    List<float> brojevi = Program.izdvojBrojeve(s);
                    if (brojevi.Count >= 3)
                        tackice.Add(new Vector3(brojevi[0], brojevi[1], brojevi[2]));
                    continue;
                }
                if (s.StartsWith("f ") || s.StartsWith("f\t"))
                {
                    List<float> brojevi = Program.izdvojBrojeve(s);
                    if (brojevi.Count == 3)
                    {
                        lica.Add(new Lice((int)brojevi[0] - 1, (int)brojevi[1] - 1, (int)brojevi[2] - 1));
                        curr.saTri = true;
                    }
                    else if (brojevi.Count == 6)
                    {
                        lica.Add(new Lice((int)brojevi[0] - 1, (int)brojevi[2] - 1, (int)brojevi[4] - 1, (int)brojevi[1] - 1, (int)brojevi[3] - 1, (int)brojevi[5] - 1));
                    }
                    else if (brojevi.Count == 12)
                    {
                        int a1 = (int)brojevi[0];
                        if (a1 < 0) continue;
                        int a2 = (int)brojevi[2];
                        if (a2 < 0) continue;
                        int b1 = (int)brojevi[3];
                        if (b1 < 0) b1 = tackice.Count + b1 - 1;
                        int b2 = (int)brojevi[5];
                        if (b2 < 0) b2 = tackice.Count + b2 - 1;
                        int c1 = (int)brojevi[6];
                        if (c1 < 0) c1 = tackice.Count + c1 - 1;
                        int c2 = (int)brojevi[8];
                        if (c2 < 0) c2 = tackice.Count + c2 - 1;
                        lica.Add(new Lice(a1 - 1, b1 - 1, c1 - 1, a2 - 1, b2 - 1, c2 - 1));
                    }
                }
            }
            if (curr != null)
            {
                curr.tackice = tackice.ToArray();
                curr.normale = normale.ToArray();
                curr.lica = lica.ToArray();
                curr.Boja = Color.AliceBlue;
            }
            return fensiLista;
        }
    }

}
