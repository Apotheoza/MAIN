﻿using SharpDX;

namespace WinFormsApp1
{
    class Kamera
    {
        public Vector3 pozicija { get; set; }
        public Vector3 meta { get; set; }
    }
    class Svetlo
    {
        public Vector3 poz { get; set; }
        public System.Drawing.Color boja { get; set; }
    }
}
