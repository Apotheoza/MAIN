namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTurn = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.lblEndTitle = new System.Windows.Forms.Label();
            this.lblEndDesc = new System.Windows.Forms.Label();
            this.btnPlayAgain = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();

            // this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(25)))));
            this.pictureBox1.Location = new System.Drawing.Point(16, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 480);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);

            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);

            this.lblTitle.AutoSize = true;
            //= this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            // this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(632, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(121, 30);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "3D CHESS";

            this.lblTurn.AutoSize = true;
            //  this.lblTurn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            // this.lblTurn.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblTurn.Location = new System.Drawing.Point(634, 65);
            this.lblTurn.Name = "lblTurn";
            this.lblTurn.Size = new System.Drawing.Size(95, 21);
            this.lblTurn.TabIndex = 2;
            this.lblTurn.Text = "Turn: White";

            this.lblStatus.AutoSize = true;
            //  this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            // this.lblStatus.ForeColor = System.Drawing.Color.Coral;
            this.lblStatus.Location = new System.Drawing.Point(634, 98);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 21);
            this.lblStatus.TabIndex = 3;

            //  this.btnNewGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(52)))), ((int)(((byte)(58)))));
            //  this.btnNewGame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            //  this.btnNewGame.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            // this.btnNewGame.ForeColor = System.Drawing.Color.White;
            this.btnNewGame.Location = new System.Drawing.Point(634, 138);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(140, 36);
            this.btnNewGame.TabIndex = 4;
            this.btnNewGame.Text = "New Game";
            //  this.btnNewGame.UseVisualStyleBackColor = false;
            this.btnNewGame.UseVisualStyleBackColor = true;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);

            this.lblEndTitle.AutoSize = true;
            // this.lblEndTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            // this.lblEndTitle.ForeColor = System.Drawing.Color.Gold;
            this.lblEndTitle.Location = new System.Drawing.Point(634, 215);
            this.lblEndTitle.Name = "lblEndTitle";
            this.lblEndTitle.Size = new System.Drawing.Size(113, 25);
            this.lblEndTitle.TabIndex = 5;
            this.lblEndTitle.Text = "VICTORY!";
            this.lblEndTitle.Visible = false;

            //  this.lblEndDesc.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            // this.lblEndDesc.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblEndDesc.Location = new System.Drawing.Point(634, 248);
            this.lblEndDesc.Name = "lblEndDesc";
            this.lblEndDesc.Size = new System.Drawing.Size(145, 45);
            this.lblEndDesc.TabIndex = 6;
            this.lblEndDesc.Text = "White wins by checkmate.";
            this.lblEndDesc.Visible = false;

            // this.btnPlayAgain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            //.btnPlayAgain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            //  this.btnPlayAgain.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            // this.btnPlayAgain.ForeColor = System.Drawing.Color.White;
            this.btnPlayAgain.Location = new System.Drawing.Point(634, 305);
            this.btnPlayAgain.Name = "btnPlayAgain";
            this.btnPlayAgain.Size = new System.Drawing.Size(140, 36);
            this.btnPlayAgain.TabIndex = 7;
            this.btnPlayAgain.Text = "Play Again";
            //  this.btnPlayAgain.UseVisualStyleBackColor = false;
            this.btnPlayAgain.UseVisualStyleBackColor = true;
            this.btnPlayAgain.Visible = false;
            this.btnPlayAgain.Click += new System.EventHandler(this.btnPlayAgain_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(33)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(796, 512);
            this.Controls.Add(this.btnPlayAgain);
            this.Controls.Add(this.lblEndDesc);
            this.Controls.Add(this.lblEndTitle);
            this.Controls.Add(this.btnNewGame);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblTurn);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "3D Chess";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Zatvaranje);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblTurn;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Label lblEndTitle;
        private System.Windows.Forms.Label lblEndDesc;
        private System.Windows.Forms.Button btnPlayAgain;
    }
}
