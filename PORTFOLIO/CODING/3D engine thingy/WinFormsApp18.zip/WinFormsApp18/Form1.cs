using ChessConsole;
using SharpDX;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Websocket.Client;
using Color = System.Drawing.Color;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        Engine engine;
        Kamera kam;
        Objekat polje;
        Objekat konj;
        Objekat kralj;
        Objekat kraljica;
        Objekat lovac;
        Objekat top;
        Objekat piun;
        Objekat trofej;

        public bool pobedio = false;
        string endGameMessage = "";
        Svetlo svetlo;

        public Bitmap bmp;
        public Keys PressedKey;
        ChessGame game;

        WebsocketClient ws;
        int mojaBoja;
        string id;
        bool renderloop = false;
        bool connectionOpen = false;

        public Color crneFig = Color.FromArgb(59, 60, 54);
        public Color beleFig = Color.AntiqueWhite;
        public Color belaPolja = Color.PapayaWhip;
        public Color crnaPolja = Color.DarkCyan;
        public static float offset = 14f;
        int timercount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Flush()
        {
            engine.Flush();
            if (pobedio && !string.IsNullOrEmpty(endGameMessage))
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    using (SolidBrush bg = new SolidBrush(Color.FromArgb(190, 20, 20, 25)))
                    {
                        g.FillRectangle(bg, 0, bmp.Height - 70, bmp.Width, 70);
                    }
                    using (Font font = new Font("Segoe UI", 16, FontStyle.Bold))
                    using (SolidBrush textBrush = new SolidBrush(Color.White))
                    using (StringFormat sf = new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                    {
                        g.DrawString(endGameMessage, font, textBrush, new System.Drawing.RectangleF(0, bmp.Height - 70, bmp.Width, 70), sf);
                    }
                }
            }
            pictureBox1.Image = bmp;
        }

        private Objekat loadFirstOrFallback(string filename, float shine, float shineS)
        {
            var list = Objekat.UcitajIzFajla(filename);
            Objekat result = null;
            if (list != null && list.Count > 0)
            {
                result = list[0];
            }
            else
            {
                result = new Objekat(Path.GetFileNameWithoutExtension(filename), 8, 6, 12);
                result.tackice[0] = new Vector3(-3, -3, -3);
                result.tackice[1] = new Vector3(-3, -3, 3);
                result.tackice[2] = new Vector3(-3, 3, -3);
                result.tackice[3] = new Vector3(-3, 3, 3);
                result.tackice[4] = new Vector3(3, -3, -3);
                result.tackice[5] = new Vector3(3, -3, 3);
                result.tackice[6] = new Vector3(3, 3, -3);
                result.tackice[7] = new Vector3(3, 3, 3);

                result.normale[0] = new Vector3(0, 0, 1);
                result.normale[1] = new Vector3(0, 0, -1);
                result.normale[2] = new Vector3(0, 1, 0);
                result.normale[3] = new Vector3(0, -1, 0);
                result.normale[4] = new Vector3(1, 0, 0);
                result.normale[5] = new Vector3(-1, 0, 0);

                result.lica[0] = new Lice(0, 1, 2, 5, 5, 5);
                result.lica[1] = new Lice(1, 3, 2, 5, 5, 5);
                result.lica[2] = new Lice(3, 7, 2, 2, 2, 2);
                result.lica[3] = new Lice(2, 7, 6, 2, 2, 2);
                result.lica[4] = new Lice(2, 6, 4, 1, 1, 1);
                result.lica[5] = new Lice(2, 4, 0, 1, 1, 1);
                result.lica[6] = new Lice(5, 4, 6, 4, 4, 4);
                result.lica[7] = new Lice(5, 6, 7, 4, 4, 4);
                result.lica[8] = new Lice(1, 5, 3, 0, 0, 0);
                result.lica[9] = new Lice(5, 7, 3, 0, 0, 0);
                result.lica[10] = new Lice(5, 1, 0, 3, 3, 3);
                result.lica[11] = new Lice(5, 0, 4, 3, 3, 3);
            }
            result.shine = shine;
            result.shineS = shineS;
            return result;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            game = new ChessGame();
            svetlo = new Svetlo();
            svetlo.poz = new Vector3(30, 90, 0);
            svetlo.boja = Color.FromArgb(255, 214, 170);
            bmp = new Bitmap(600, 480);
            pictureBox1.Size = new Size(bmp.Width, bmp.Height);
            engine = new Engine(bmp);
            kam = new Kamera();
            kam.pozicija = new Vector3(170, 270, 0);
            kam.meta = Vector3.Zero;
            engine.Clear();
            Flush();

            polje = loadFirstOrFallback("polje.obj", 8, 0.5f);
            trofej = loadFirstOrFallback("pehar.obj", 32, 1f);
            konj = loadFirstOrFallback("skakac.obj", 32, 0.7f);
            piun = loadFirstOrFallback("pesak.obj", 32, 1f);
            kralj = loadFirstOrFallback("kralj.obj", 32, 1f);
            kraljica = loadFirstOrFallback("kraljica.obj", 32, 1f);
            lovac = loadFirstOrFallback("lovac.obj", 32, 1f);
            top = loadFirstOrFallback("top.obj", 32, 1f);

            trofej.pozicija = new Vector3(0, -10, 0);
            kraljica.Boja = Color.Purple;
            rfrsh();

            try
            {
                ws = new WebsocketClient(new Uri("ws://localhost:4649/Chess"));
                ws.MessageReceived.Subscribe(msg =>
                {
                    if (string.IsNullOrEmpty(msg.Text)) return;
                    try
                    {
                        this.BeginInvoke((MethodInvoker)delegate
                        {
                            string[] s = msg.Text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            if (msg.Text == "PONG")
                            {
                                connectionOpen = true;
                            }
                            if (s.Length > 1 && s[0] == "id")
                            {
                                id = s[1];
                            }
                            if (s.Length > 1 && s[0] == "boja")
                            {
                                mojaBoja = int.Parse(s[1]);
                                if (mojaBoja == 1)
                                    kam.pozicija = new Vector3(0, 200, 150);
                                else
                                    kam.pozicija = new Vector3(0, 200, -150);
                                game.UpdateColor(mojaBoja);
                                rfrsh();
                            }
                            if (s.Length >= 6 && s[0] == "potez" && int.Parse(s[1]) != mojaBoja)
                            {
                                lock (game)
                                {
                                    game.turnOver(int.Parse(s[2]), int.Parse(s[3]), int.Parse(s[4]), int.Parse(s[5]));
                                }
                                rfrsh();
                            }
                        });
                    }
                    catch { }
                });
                ws.ErrorReconnectTimeout = TimeSpan.FromMilliseconds(1000);
                ws.Start();
            }
            catch { }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timercount >= 1500)
            {
                if (connectionOpen)
                {
                    if (ws != null && ws.IsRunning)
                    {
                        try { ws.Send("PING"); } catch { }
                    }
                    connectionOpen = false;
                }
                else
                {
                    if (ws != null && !ws.IsRunning)
                    {
                        try { _ = ws.Reconnect(); } catch { }
                    }
                }
                timercount = 0;
            }
            timercount++;

            if (pobedio)
            {
                if (trofej != null)
                {
                    trofej.rotacija = new Vector3(0, trofej.rotacija.Y + 0.03f, 0);
                    engine.Clear();
                    engine.Crtaj(kam, svetlo, trofej);
                    Flush();
                }
                return;
            }

            if (!renderloop)
                return;

            Vector3 delta = Vector3.Zero;
            if (PressedKey == Keys.A)
            {
                delta += Vector3.Cross(kam.pozicija - kam.meta, Vector3.UnitY);
            }
            else if (PressedKey == Keys.D)
            {
                delta += Vector3.Cross(Vector3.UnitY, kam.pozicija - kam.meta);
            }
            else if (PressedKey == Keys.S)
            {
                delta += Vector3.Cross(Vector3.Cross(Vector3.UnitY, kam.pozicija - kam.meta), kam.pozicija - kam.meta);
            }
            else if (PressedKey == Keys.W)
            {
                delta += Vector3.Cross(kam.pozicija - kam.meta, Vector3.Cross(Vector3.UnitY, kam.pozicija - kam.meta));
            }
            else if (PressedKey == Keys.J)
            {
                var dir = kam.pozicija - kam.meta;
                if (dir.LengthSquared() > 0)
                    delta += Vector3.Normalize(dir);
            }
            else if (PressedKey == Keys.K)
            {
                var dir = kam.pozicija - kam.meta;
                if (dir.LengthSquared() > 0)
                    delta -= Vector3.Normalize(dir);
            }
            else if (PressedKey == Keys.R)
            {
                var cross = Vector3.Cross(Vector3.UnitY, svetlo.poz);
                if (cross.LengthSquared() > 0)
                    svetlo.poz += Vector3.Normalize(cross);
            }
            else if (PressedKey == Keys.T)
            {
                svetlo.poz += Vector3.Up;
            }
            else if (PressedKey == Keys.G)
            {
                svetlo.poz += Vector3.Down;
            }

            if (delta.LengthSquared() > 0)
            {
                delta.Normalize();
                delta *= 4;
                kam.pozicija += delta;
            }
            rfrsh();
        }

        void rfrsh()
        {
            engine.Clear();
            string temp;
            lock (game)
            {
                if (game.IsGameOver && !pobedio)
                {
                    pobeda(game.Winner);
                    return;
                }

                temp = game.Write();
                string[] s = temp.Split();
                string boardState = s.Length > 0 ? s[0] : "";
                string moves = s.Length > 1 ? s[1] : "";

                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        polje.pozicija = new Vector3(i * offset - 4 * offset + 7, -5f, j * offset - 4 * offset + 7);
                        if ((i + j) % 2 == 0)
                        {
                            polje.Boja = belaPolja;
                        }
                        else polje.Boja = crnaPolja;

                        if (moves.Contains(i + "" + j))
                        {
                            polje.Boja = Color.YellowGreen;
                            if (boardState.Length > (i * 8 + j) && boardState[i * 8 + j] != 'n')
                                polje.Boja = Color.Coral;
                        }
                        engine.Crtaj(kam, svetlo, i * 8 + j, polje);

                        Objekat pieceObj = null;
                        if (boardState.Length > (i * 8 + j) && boardState[i * 8 + j] != 'n')
                        {
                            char ch = boardState[i * 8 + j];
                            if (char.ToLower(ch) == 'h')
                            {
                                pieceObj = konj;
                                if (char.IsLower(ch))
                                    pieceObj.rotacija = new Vector3(0, 1.5f, 0);
                                else
                                    pieceObj.rotacija = new Vector3(0, -1.5f, 0);
                            }
                            else if (char.ToLower(ch) == 'r')
                            {
                                pieceObj = top;
                            }
                            else if (char.ToLower(ch) == 'k')
                            {
                                pieceObj = kralj;
                            }
                            else if (char.ToLower(ch) == 'q')
                            {
                                pieceObj = kraljica;
                            }
                            else if (char.ToLower(ch) == 'b')
                            {
                                pieceObj = lovac;
                            }
                            else if (char.ToLower(ch) == 'p')
                            {
                                pieceObj = piun;
                            }

                            if (pieceObj != null)
                            {
                                pieceObj.pozicija = new Vector3(i * offset - 4 * offset + 7, 0.5f, j * offset - 4 * offset + 7);
                                if (char.IsLower(ch))
                                {
                                    pieceObj.Boja = crneFig;
                                }
                                else
                                    pieceObj.Boja = beleFig;
                                engine.Crtaj(kam, svetlo, i * 8 + j, pieceObj);
                            }
                        }
                    }
                }

                Flush();

                if (!pobedio)
                {
                    lblTurn.Text = "Turn: " + (game.CurrentPlayer == PlayerColor.White ? "White" : "Black");
                    lblStatus.Text = game.InCheck ? "CHECK!" : "";
                }
            }
        }

        void pobeda(PlayerColor winner)
        {
            engine.Clear();
            pobedio = true;
            kam.pozicija = new Vector3(0, 0, 200);
            kam.meta = Vector3.Zero;
            if (winner == PlayerColor.White)
            {
                trofej.Boja = beleFig;
                endGameMessage = "White Wins by Checkmate!";
                lblEndTitle.Text = "VICTORY!";
                lblEndDesc.Text = "White wins by checkmate.";
            }
            else if (winner == PlayerColor.Black)
            {
                trofej.Boja = crneFig;
                endGameMessage = "Black Wins by Checkmate!";
                lblEndTitle.Text = "VICTORY!";
                lblEndDesc.Text = "Black wins by checkmate.";
            }
            else
            {
                trofej.Boja = Color.Gold;
                endGameMessage = "Stalemate - Draw!";
                lblEndTitle.Text = "STALEMATE!";
                lblEndDesc.Text = "Game ended in a draw.";
            }
            lblTurn.Text = "Game Over";
            lblStatus.Text = "";
            lblEndTitle.Visible = true;
            lblEndDesc.Visible = true;
            btnPlayAgain.Visible = true;
            engine.Crtaj(kam, svetlo, trofej);
            Flush();
        }

        private void RestartGame()
        {
            lock (game)
            {
                game = new ChessGame();
                pobedio = false;
                endGameMessage = "";
                lblEndTitle.Visible = false;
                lblEndDesc.Visible = false;
                btnPlayAgain.Visible = false;
                kam.pozicija = new Vector3(170, 270, 0);
                kam.meta = Vector3.Zero;
            }
            rfrsh();
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            RestartGame();
        }

        private void btnPlayAgain_Click(object sender, EventArgs e)
        {
            RestartGame();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (pobedio)
                return;

            System.Drawing.Point p = pictureBox1.PointToClient(Cursor.Position);
            if (p.X < 0 || p.Y < 0 || p.X >= bmp.Width || p.Y >= bmp.Height)
                return;

            int temp = engine.pozicije[p.X, p.Y];
            if (temp < 0 || temp >= 64)
            {
                game.Cancel();
                rfrsh();
                return;
            }

            int xprim = temp / 8;
            int yprim = temp % 8;
            string s = game.Update(xprim, yprim);
            if (s != null)
            {
                if (ws != null && ws.IsRunning)
                {
                    try { ws.Send(s); } catch { }
                }
            }

            rfrsh();
        }

        private void Zatvaranje(object sender, FormClosedEventArgs e)
        {
            try { ws?.Dispose(); } catch { }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                game.Cancel();
                rfrsh();
                return;
            }
            PressedKey = e.KeyCode;
            renderloop = true;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (PressedKey == e.KeyCode)
                PressedKey = Keys.F17;
            renderloop = false;
        }
    }
}
