﻿using System.Collections.Generic;

namespace WinFormsApp1
{
    class Sah
    {
        public static bool select = false;
        public static int turn = -1;
        public static int[] selektovano;
        public static bool[,] zelena = new bool[8, 8];
        public static figura[,] tabla = {
            { new top(1), new konj(1), new lovac(1), new kralj(1), new kraljica(1), new lovac(1), new konj(1), new top(1) },
            { new piun(1), new piun(1), new piun(1), new piun(1), new piun(1), new piun(1), new piun(1), new piun(1) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            { new piun(-1), new piun(-1), new piun(-1), new piun(-1), new piun(-1), new piun(-1), new piun(-1), new piun(-1) },
            { new top(-1), new konj(-1), new lovac(-1), new kralj(-1), new kraljica(-1), new lovac(-1), new konj(-1), new top(-1) },
        };
        public static void pomeri(int[] podaci)
        {
            if (!select && turn == tabla[podaci[0], podaci[1]].boja)
            {
                selektovano = podaci;
                select = true;
                zelena = svapolja(podaci, tabla);
            }
            else if (select)
            {
                int[] destinacija = podaci;
                figura[,] tablaprim = (figura[,])tabla.Clone();
                tablaprim[destinacija[0], destinacija[1]] = tabla[selektovano[0], selektovano[1]];
                tablaprim[selektovano[0], selektovano[1]] = new polje(0);
                if (!menisah(tablaprim) && moze(selektovano, destinacija))
                {
                    tabla[destinacija[0], destinacija[1]] = tabla[selektovano[0], selektovano[1]];
                    tabla[selektovano[0], selektovano[1]] = new polje(0);
                    select = false;
                    if (tabla[destinacija[0], destinacija[1]] is piun && tabla[destinacija[0], destinacija[1]].boja == -1 && destinacija[0] == 0)
                    {
                        tabla[destinacija[0], destinacija[1]] = biarj(-1);
                    }
                    if (tabla[destinacija[0], destinacija[1]] is piun && tabla[destinacija[0], destinacija[1]].boja == 1 && destinacija[0] == 7)
                    {
                        tabla[destinacija[0], destinacija[1]] = biarj(1);
                    }
                    turn = -turn;


                }
                else
                {
                    select = false;
                }

                zelena = new bool[8, 8];
            }
        }
        public static figura biarj(int a)
        {
            return new kraljica(a);
        }
        public static bool moze(int[] selektovano, int[] destinacija)
        {
            if (svapolja(selektovano, tabla)[destinacija[0], destinacija[1]] == true)
            {
                return true;
            }
            return false;
        }
        public static bool[,] svapolja(int[] selektovano, figura[,] tabla)
        {
            bool[,] dostupnapolja = new bool[8, 8];
            if (tabla[selektovano[0], selektovano[1]] is piun)
            {
                dostupnapolja = pun(selektovano, tabla);
            }
            else
            {
                int[] svapravila = tabla[selektovano[0], selektovano[1]].mr;
                foreach (int x in svapravila)
                {
                    dostupnapolja = dijag(figura.pravila[x, 0], figura.pravila[x, 1], dostupnapolja, tabla, selektovano);
                    dostupnapolja = dijag(-figura.pravila[x, 0], figura.pravila[x, 1], dostupnapolja, tabla, selektovano);
                    dostupnapolja = dijag(figura.pravila[x, 0], -figura.pravila[x, 1], dostupnapolja, tabla, selektovano);
                    dostupnapolja = dijag(-figura.pravila[x, 0], -figura.pravila[x, 1], dostupnapolja, tabla, selektovano);
                    dostupnapolja = dijag(figura.pravila[x, 1], figura.pravila[x, 0], dostupnapolja, tabla, selektovano);
                    dostupnapolja = dijag(-figura.pravila[x, 1], figura.pravila[x, 0], dostupnapolja, tabla, selektovano);
                    dostupnapolja = dijag(figura.pravila[x, 1], -figura.pravila[x, 0], dostupnapolja, tabla, selektovano);
                    dostupnapolja = dijag(-figura.pravila[x, 1], -figura.pravila[x, 0], dostupnapolja, tabla, selektovano);
                }
            }
            return dostupnapolja;
        }
        public static bool[,] pun(int[] sel, figura[,] tabla)
        {
            bool[,] dostupnapolja = new bool[8, 8];
            int tempa = sel[0];
            int tempb = sel[1];
            if (tabla[tempa, tempb].boja == 1)
            {
                if (inrange(tempa + 1, tempb + 1) && tabla[tempa + 1, tempb + 1].boja == -1)
                {
                    dostupnapolja[tempa + 1, tempb + 1] = true;
                }
                if (inrange(tempa + 1, tempb - 1) && tabla[tempa + 1, tempb - 1].boja == -1)
                {
                    dostupnapolja[tempa + 1, tempb - 1] = true;
                }
                if (tempa == 1)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        tempa++;
                        if (tabla[tempa, tempb].boja != 0)
                        {
                            break;
                        }
                        dostupnapolja[tempa, tempb] = true;
                    }
                }
                else
                {
                    if (inrange(tempa + 1, tempb) && tabla[tempa + 1, tempb].boja == 0)
                    {
                        dostupnapolja[tempa + 1, tempb] = true;
                    }
                }


            }
            else
            {
                if (inrange(tempa - 1, tempb + 1) && tabla[tempa - 1, tempb + 1].boja == 1)
                {
                    dostupnapolja[tempa - 1, tempb + 1] = true;
                }
                if (inrange(tempa - 1, tempb - 1) && tabla[tempa - 1, tempb - 1].boja == 1)
                {
                    dostupnapolja[tempa - 1, tempb - 1] = true;
                }
                if (tempa == 6)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        tempa--;
                        if (tabla[tempa, tempb].boja != 0)
                        {
                            break;
                        }
                        dostupnapolja[tempa, tempb] = true;
                    }
                }
                else
                {
                    if (inrange(tempa - 1, tempb) && tabla[tempa - 1, tempb].boja == 0)
                    {
                        dostupnapolja[tempa - 1, tempb] = true;
                    }
                }
            }
            return dostupnapolja;
        }
        public static bool[,] dijag(int a, int b, bool[,] dostupnapolja, figura[,] tabla, int[] sel)
        {
            int tempa = sel[0];
            int tempb = sel[1];

            while (true)
            {
                tempa += a;
                tempb += b;
                if (inrange(tempa, tempb) && tabla[tempa, tempb].boja != tabla[sel[0], sel[1]].boja)
                {
                    if (tabla[tempa, tempb].boja != 0)
                    {
                        dostupnapolja[tempa, tempb] = true;
                        break;
                    }
                    dostupnapolja[tempa, tempb] = true;
                    if (tabla[sel[0], sel[1]] is kralj || tabla[sel[0], sel[1]] is konj)
                    {
                        break;
                    }
                }
                else break;
            }
            return dostupnapolja;
        }
        public static bool sahmat(figura[,] tabla)
        {
            List<List<int>> kord = new List<List<int>>();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (tabla[i, j].boja == turn)
                    {
                        List<int> temp = new List<int>();
                        temp.Add(i);
                        temp.Add(j);
                        kord.Add(temp);
                    }
                }
            }
            foreach (List<int> x in kord)
            {
                bool[,] sp = svapolja(x.ToArray(), tabla);
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (sp[i, j])
                        {
                            figura[,] novatabla = (figura[,])tabla.Clone();
                            novatabla[i, j] = novatabla[x[0], x[1]];
                            novatabla[x[0], x[1]] = new polje(0);
                            if (!menisah(novatabla))
                            {
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        }
        public static bool menisah(figura[,] tabla)
        {
            int[] kraljpozicija = new int[2];
            List<List<int>> cord = new List<List<int>>();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (tabla[i, j].boja == -turn)
                    {
                        List<int> temp = new List<int>();
                        temp.Add(i);
                        temp.Add(j);
                        cord.Add(temp);
                    }
                    if (tabla[i, j] is kralj && tabla[i, j].boja == turn)
                    {
                        kraljpozicija[0] = i;
                        kraljpozicija[1] = j;
                    }
                }
            }
            foreach (List<int> poz in cord)
            {
                bool[,] matrica = svapolja(poz.ToArray(), tabla);
                if (matrica[kraljpozicija[0], kraljpozicija[1]] == true)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool inrange(int a, int b)
        {
            if (a >= 0 && a <= 7 && b >= 0 && b <= 7)
            {
                return true;
            }
            return false;
        }
        /*
        public static int turn = 1;
        public static int[] sel = new int[2];
        public static int[] gl = new int[2];
        public static bool std = false;
        public static string trg;
        public static int[,] figura.pravila = new int[,] { { 1, 0, 1 }, { 1, 2, 0 }, { 1, 1, 1 }, { 1, 1, 0 }, { 1, 0, 0 } };
        public static figura[,] tabla = {
            { new top(1), new konj(1), new lovac(1), new kraljica(1), new kralj(1), new lovac(1), new konj(1), new top(1) },
            { new piun(1), new piun(1), new piun(1), new piun(1), new piun(1), new piun(1), new piun(1), new piun(1) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            {new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0), new polje(0) },
            { new piun(2), new piun(2), new piun(2), new piun(2), new piun(2), new piun(2), new piun(2), new piun(2) },
            { new top(2), new konj(2), new lovac(2), new kraljica(2), new kralj(2), new lovac(2), new konj(2), new top(2) },
        };
        public static int[,] dostupnapolja = {
        {1,1,1,1,1,1,1,1},{1,1,1,1,1,1,1,1},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0 },{0,0,0,0,0,0,0,0 },{0,0,0,0,0,0,0,0 },{0,0,0,0,0,0,0,0 },{2,2,2,2,2,2,2,2 },{ 2,2,2,2,2,2,2,2}
        };
        public static void pomeri(int a, int b)
        {
            if ((!std || tabla[a, b].boja == tabla[sel[0], sel[1]].boja) && tabla[a, b].boja != 0 && ((turn%2)+1) == tabla[a, b].boja)
            {
                genocid();
                sel = new int[] { a, b };
                std = true;
                if (tabla[a, b] is piun)
                {
                   dostupnapolja = pun(dostupnapolja, sel);
                }
                else {
                   dostupnapolja = zlrn(tabla, sel, dostupnapolja);
                }
                getall(tabla, sel, dostupnapolja);
            }
            else if (dostupnapolja[a, b] == 3)
            {              
                figura[,] tablaprim = (figura[,])tabla.Clone();
                int[,] dostupnapoljaprim = (int[,])dostupnapolja.Clone();
                tablaprim[a, b] = tabla[sel[0], sel[1]];
                tablaprim[sel[0], sel[1]] = new polje(0);
                dostupnapoljaprim[a, b] = dostupnapolja[sel[0], sel[1]];
                dostupnapoljaprim[sel[0], sel[1]] = 0;
                if (!suha(tablaprim,dostupnapoljaprim))
                {
                    std = false;
                    turn++;
                    tabla[a, b] = tabla[sel[0], sel[1]];
                    tabla[a, b] = tabla[sel[0], sel[1]];
                    tabla[sel[0], sel[1]] = new polje(0);
                    dostupnapolja[a, b] = dostupnapolja[sel[0], sel[1]];
                    dostupnapolja[sel[0], sel[1]] = 0;
                    genocid();
                }
            }

            return;
        }
        public static bool pomeridatu(int a, int b, figura[,] tabla, int[,] dostupnapolja, int[] sel)
        {
                if(tabla[sel[0], sel[1]] is piun)
                {
                    dostupnapolja = pun(dostupnapolja, sel);
                }
                else
                {
                    dostupnapolja = zlrn(tabla, sel, dostupnapolja);
                }

            if (dostupnapolja[a, b] == 3)
            {
                figura[,] tablaprim = (figura[,])tabla.Clone();
                int[,] dostupnapoljaprim = dostupnapolja;
                tablaprim[a, b] = tabla[sel[0], sel[1]];
                tablaprim[sel[0], sel[1]] = new polje(0);
                dostupnapoljaprim[a, b] = dostupnapolja[sel[0], sel[1]];
                dostupnapoljaprim[sel[0], sel[1]] = 0;
                if ((turn % 2) == 0 && !suhb(tablaprim, dostupnapoljaprim))
                {
                    return false;
                }
                else if ((turn % 2) == 1 && !suha(tablaprim, dostupnapoljaprim))
                {
                    return false;
                }
            }

            return true;
        }
        public static bool sahmat(figura[,] tabla, int[,] dostupnapolja) {
            List<figura> bele = new List<figura>();
            List<List<int>> kord = new List<List<int>>();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (tabla[i, j].boja == 1)
                    {
                        bele.Add(tabla[i,j]);
                        List<int> tem = new List<int>();
                        tem.Add(i);
                        tem.Add(j);
                        kord.Add(tem);
                    }
                }
            }
            int count = 0;
            foreach (figura f in bele) {
                List<List<int>> getta = getall(tabla,kord[count].ToArray(),dostupnapolja);
                count++;
              /*  foreach (List<int> x in getta) {
                    if (!pomeridatu(x[0], x[1], tabla, dostupnapolja, kord[count].ToArray()))
                    {
                        return false;
                    }
                }
              
            }
            return true;

        }
        public static bool sahmatb(figura[,] tabla, int[,] dostupnapolja)
        {
            List<figura> bele = new List<figura>();
            List<List<int>> kord = new List<List<int>>();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (tabla[i, j].boja == 2)
                    {
                        bele.Add(tabla[i, j]);
                        List<int> tem = new List<int>();
                        tem.Add(i);
                        tem.Add(j);
                        kord.Add(tem);
                    }
                }
            }
            int count = 0;
            foreach (figura f in bele)
            {
                List<List<int>> getta = getall(tabla, kord[count].ToArray(), dostupnapolja);
                count++;
                /*  foreach (List<int> x in getta) {
                      if (!pomeridatu(x[0], x[1], tabla, dostupnapolja, kord[count].ToArray()))
                      {
                          return false;
                      }
                  }
                
            }
            return true;

        }
        public static List<List<int>> getall(figura[,] tabl, int[] sel, int[,] dostupnapolja) {
            List<List<int>> gtll = new List<List<int>>();
            int[] niska = tabl[sel[0], sel[1]].mr;
            foreach (int x in niska)
            {
                dostupnapolja = dijag(figura.pravila[x, 0], figura.pravila[x, 1], dostupnapolja, tabl, sel);
                dostupnapolja = dijag(-figura.pravila[x, 0], figura.pravila[x, 1], dostupnapolja, tabl, sel);
                dostupnapolja = dijag(figura.pravila[x, 0], -figura.pravila[x, 1], dostupnapolja, tabl, sel);
                dostupnapolja = dijag(-figura.pravila[x, 0], -figura.pravila[x, 1], dostupnapolja, tabl, sel);
                dostupnapolja = dijag(figura.pravila[x, 1], figura.pravila[x, 0], dostupnapolja, tabl, sel);
                dostupnapolja = dijag(-figura.pravila[x, 1], figura.pravila[x, 0], dostupnapolja, tabl, sel);
                dostupnapolja = dijag(figura.pravila[x, 1], -figura.pravila[x, 0], dostupnapolja, tabl, sel);
                dostupnapolja = dijag(-figura.pravila[x, 1], -figura.pravila[x, 0], dostupnapolja, tabl, sel);
            }
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (dostupnapolja[i,j]== 3)
                    {
                        List<int> tmp = new List<int>();
                        tmp.Add(i);
                        tmp.Add(j);
                        gtll.Add(tmp);
                    }
                }
            }
            return (gtll);

        }
        public static bool suha(figura[,] blat, int[,] dostupnapolja)
        {
            int[] kra = new int[2];
            List<List<int>> aa = new List<List<int>>();
            List<figura> gis = new List<figura>();
            int[,] dwd = dostupnapolja;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (blat[i,j].boja == turn%2)
                    {
                        List<int> s = new List<int>();
                        s.Add(i);
                        s.Add(j);
                        aa.Add(s);
                        gis.Add(blat[i, j]);
                    }
                    int c = 1;
                    if (turn%2 == 1)
                    {
                        c = 2;
                    }
                    if (blat[i, j] is kralj&&blat[i, j].boja == c)
                    {
                        kra[0] = i;
                        kra[1] = j;
                    }
                }
            }
            int count = 0;
            foreach (figura f in gis) {
                dwd = dostupnapolja;
                List<int> sdds = aa[count];
                count++;
                if (f is piun)
                {
                    dwd = pun(dwd, sdds.ToArray());
                    if (dwd[kra[0], kra[1]] == 3)
                    {
                        return true;
                    }
                }
                else
                {
                    dwd = zlrn(blat, sdds.ToArray(), dwd);
                    if (dwd[kra[0], kra[1]] == 3)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public static bool suhb(figura[,] blat, int[,] dostupnapolja)
        {
            int[] kra = new int[2];
            List<List<int>> aa = new List<List<int>>();
            List<figura> gis = new List<figura>();
            int[,] dwd = dostupnapolja;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (blat[i, j].boja == 2)
                    {
                        List<int> s = new List<int>();
                        s.Add(i);
                        s.Add(j);
                        aa.Add(s);
                        gis.Add(blat[i, j]);
                    }
                    if (blat[i, j] is kralj && blat[i, j].boja == 1)
                    {
                        kra[0] = i;
                        kra[1] = j;
                    }
                }
            }
            int count = 0;
            foreach (figura f in gis)
            {
                dwd = dostupnapolja;
                List<int> sdds = aa[count];
                count++;
                if (f is piun)
                {
                    dwd = pun(dwd, sdds.ToArray());
                    if (dwd[kra[0], kra[1]] == 3)
                    {
                        return true;
                    }
                }
                else
                {
                    dwd = zlrn(blat, sdds.ToArray(), dwd);
                    if (dwd[kra[0], kra[1]] == 3)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public static void genocid()
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (tabla[i, j] is polje)
                    {
                        dostupnapolja[i, j] = 0;
                    }
                    else if (tabla[i, j].boja == 1)
                    {
                        dostupnapolja[i, j] = 1;
                    }
                    else
                        dostupnapolja[i, j] = 2;
                }
            }
        }
        public static bool inrange(int a, int b)
        {
            if (a >= 0 && a <= 7 && b >= 0 && b <= 7)
            {
                return true;
            }
            return false;
        }
        public static int[,] dijag(int a, int b, int[,] dostupnapolja, figura[,] tabla, int[] sel)
        {
            int tempa = sel[0];
            int tempb = sel[1];

            while (true)
            {
                tempa += a;
                tempb += b;
                if (inrange(tempa, tempb) && tabla[tempa, tempb].boja != tabla[sel[0], sel[1]].boja)
                {
                    if (dostupnapolja[tempa, tempb] != 0)
                    {
                        dostupnapolja[tempa, tempb] = 3;
                        break;
                    }
                    dostupnapolja[tempa, tempb] = 3;
                    if (tabla[sel[0], sel[1]] is kralj || tabla[sel[0], sel[1]] is konj)
                    {
                        break;
                    }
                }
                else break;
            }
            return dostupnapolja;
        }
        public static int[,] zlrn(figura[,] tabla, int[] sel, int[,] dostupnapolja)
        {

            int[] niska = tabla[sel[0], sel[1]].mr;
            foreach (int x in niska)
            {
                dostupnapolja = dijag(figura.pravila[x, 0], figura.pravila[x, 1], dostupnapolja, tabla, sel);
                dostupnapolja = dijag(-figura.pravila[x, 0], figura.pravila[x, 1], dostupnapolja, tabla, sel);
                dostupnapolja = dijag(figura.pravila[x, 0], -figura.pravila[x, 1], dostupnapolja, tabla, sel);
                dostupnapolja = dijag(-figura.pravila[x, 0], -figura.pravila[x, 1], dostupnapolja, tabla, sel);
                dostupnapolja = dijag(figura.pravila[x, 1], figura.pravila[x, 0], dostupnapolja, tabla, sel);
                dostupnapolja = dijag(-figura.pravila[x, 1], figura.pravila[x, 0], dostupnapolja, tabla, sel);
                dostupnapolja = dijag(figura.pravila[x, 1], -figura.pravila[x, 0], dostupnapolja, tabla, sel);
                dostupnapolja = dijag(-figura.pravila[x, 1], -figura.pravila[x, 0], dostupnapolja, tabla, sel);
            }
            return dostupnapolja;
        }
        public static int[,] pun(int[,] dostupnapolja, int[] sel)
        {
            int tempa = sel[0];
            int tempb = sel[1];
            if (dostupnapolja[tempa,tempb]==1)
            {
                if (inrange(tempa + 1, tempb +1) && dostupnapolja[tempa+1,tempb+1]==2) {
                    dostupnapolja[tempa + 1, tempb + 1] = 3;
                }
                if (inrange(tempa + 1, tempb - 1)&& dostupnapolja[tempa + 1, tempb - 1] == 2)
                {
                    dostupnapolja[tempa + 1, tempb - 1] = 3;
                }
                if (tempa == 1)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        tempa++;
                        if (dostupnapolja[tempa, tempb] != 0)
                        {
                            break;
                        }
                        dostupnapolja[tempa, tempb] = 3;
                    }
                }
                else
                {
                    if (inrange(tempa+1, tempb)&&dostupnapolja[tempa+1,tempb]==0)
                    {
                        dostupnapolja[tempa+1, tempb] = 3;
                    }
                }
              

            }
            else
            {
                if (inrange(tempa- 1, tempb + 1) && dostupnapolja[tempa - 1, tempb + 1] == 1)
                {
                    dostupnapolja[tempa - 1, tempb + 1] = 3;
                }
                if (inrange(tempa - 1, tempb - 1) && dostupnapolja[tempa - 1, tempb - 1] == 1)
                {
                    dostupnapolja[tempa - 1, tempb - 1] = 3;
                }
                if (tempa == 6)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        tempa--;
                        if (dostupnapolja[tempa, tempb] != 0)
                        {
                            break;
                        }
                        dostupnapolja[tempa, tempb] = 3;
                    }
                }
                else
                {
                    if (inrange(tempa - 1, tempb) && dostupnapolja[tempa - 1, tempb] == 0)
                    {
                        dostupnapolja[tempa - 1, tempb] = 3;
                    }
                }
            }
            return dostupnapolja;
        }
        */
    }
}

