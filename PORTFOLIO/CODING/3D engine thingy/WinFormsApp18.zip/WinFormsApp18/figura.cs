﻿namespace WinFormsApp1
{

    public abstract class figura
    {
        public static int[,] pravila = new int[,] { { 1, 0 }, { 1, 2 }, { 1, 1 } };
        public abstract string ime { get; }
        public abstract int[] mr { get; }
        public int boja;
        public figura(int b)
        {
            this.boja = b;
        }
    }
    class top : figura
    {
        public top(int b) : base(b)
        {
            this.boja = b;
        }

        public override string ime
        {
            get
            {
                return "top";
            }
        }
        public override int[] mr
        {
            get
            {
                return new int[] { 0 };
            }
        }

    }
    class konj : figura
    {
        public konj(int b) : base(b)
        {
            this.boja = b;
        }

        public override string ime
        {
            get
            {
                return "konj";
            }
        }

        public override int[] mr
        {
            get
            {
                return new int[] { 1 };
            }
        }
    }
    class piun : figura
    {
        public piun(int b) : base(b)
        {
            this.boja = b;
        }

        public override string ime
        {
            get
            {
                return "piun";
            }
        }

        public override int[] mr
        {
            get
            {
                return new int[] { };
            }
        }
    }
    class zelenko : figura
    {
        public zelenko(int b) : base(b)
        {
            this.boja = 0;
        }

        public override string ime
        {
            get
            {
                return "zelenko";
            }
        }

        public override int[] mr
        {
            get
            {
                return new int[] { };
            }
        }
    }
    class lovac : figura
    {
        public lovac(int b) : base(b)
        {
            this.boja = b;
        }

        public override string ime
        {
            get
            {
                return "lovac";
            }
        }
        public override int[] mr
        {
            get
            {
                return new int[] { 2 };
            }
        }
    }
    class kralj : figura
    {
        public kralj(int b) : base(b)
        {
            this.boja = b;
        }

        public override string ime
        {
            get
            {
                return "kralj";
            }
        }
        public override int[] mr
        {
            get
            {
                return new int[] { 0, 2 };
            }
        }
    }
    class kraljica : figura
    {

        public kraljica(int b) : base(b)
        {
            this.boja = b;
        }
        public override string ime
        {
            get
            {
                return "kraljica";
            }
        }
        public override int[] mr
        {
            get
            {
                return new int[] { 0, 2 };
            }
        }
    }
    class polje : figura
    {
        public polje(int b) : base(b)
        {
            this.boja = b;
        }

        public override string ime
        {
            get
            {
                return "polje";
            }
        }
        public override int[] mr
        {
            get
            {
                return new int[] { };
            }
        }
    }
}
