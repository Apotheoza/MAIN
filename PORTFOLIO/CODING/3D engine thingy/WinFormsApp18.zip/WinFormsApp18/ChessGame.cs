namespace ChessConsole
{
    public enum PlayerColor
    {
        White, Black, Spectator
    }

    public enum PlayerState
    {
        Idle, Holding, AwaitPromote, GameOver
    }

    public enum PromoteOptions
    {
        Queen = 0, Rook = 1, Bishop = 2, Knight = 3
    }

    public class ChessGame
    {
        /// <summary>
        /// False indicates the game should exit
        /// </summary>
        public bool Running
        {
            private set;
            get;
        }

        public PlayerState playerState;
        private PlayerColor mojaboja;

        /// <summary>
        /// Currently selected promote option
        /// </summary>
        private PromoteOptions promoteOption;

        /// <summary>
        /// True for white, false for black
        /// </summary>
        private PlayerColor currentPlayer;

        /// <summary>
        /// Coordinates for the virtual cursor on the board
        /// </summary>
        private int cursorX, cursorY;

        /// <summary>
        /// The actual chess board
        /// </summary>
        private ChessBoard board;

        /// <summary>
        /// Currently holded piece's parent cell
        /// </summary>
        private ChessBoard.Cell holdedNode = null;

        /// <summary>
        /// Where to move
        /// </summary>
        private ChessBoard.Cell moveTo = null;

        public ChessGame()
        {
            Running = true;
            board = new ChessBoard();
            currentPlayer = PlayerColor.White;
            mojaboja = PlayerColor.Spectator;
            turnStart();
        }

        #region PublicInterfaceCommands
        public string Update(int i, int j)
        {
            cursorX = i;
            cursorY = j;
            return interact();
        }

        /// <summary>
        /// Draws the game
        /// </summary>
        /// <param name="g">ConsoleGraphics object to draw with/to</param>
        public string Write()
        {
            /*g.FillArea(new CChar(' ', ConsoleColor.Black, ConsoleColor.DarkGray), 10, 5, 8, 8);

           //7-j everywhere cuz it's reversed in chess
           for (int i = 0; i < 8; i++)
           {
                for (int j = 0; j < 8; j++)
                {
                    //Draw the symbol
                    ChessBoard.Cell cell = board.GetCell(i, j);
                    if (cell.Piece != null)
                    {
                        g.DrawTransparent(cell.Piece.Char, (cell.Piece.Color == PlayerColor.White) ? ConsoleColor.White : ConsoleColor.Black, 10 + i, 5 + (7 - j));
                        if (cell.Piece.LegalMoves.Count == 0)
                        {
                            g.SetBackground(ConsoleColor.DarkRed, 10 + i, 5 + (7 - j));
                        }
                    }

                    if (cell.HitBy.Contains(debugPiece))
                        g.SetBackground(ConsoleColor.DarkMagenta, 10 + i, 5 + (7 - j));
                }
            }

            if (holdedNode != null && playerState == PlayerState.Holding)
            {
                //Highlight legal moves
                foreach (ChessBoard.Cell move in holdedNode.Piece.LegalMoves)
                {
                    g.SetBackground(ConsoleColor.DarkGreen, 10 + move.X, 5 + (7 - move.Y));
                }
            }
            
            //Sets the cursor color -> yellow
            g.SetBackground(ConsoleColor.DarkYellow, 10 + cursorX, 5 + (7 - cursorY));

            //TODO: Remove en passant testing
            *//*if (board.EnPassant != null)
                g.SetBackground(ConsoleColor.DarkCyan, 10 + board.EnPassant.X, 5 + (7 - board.EnPassant.Y));

            if (board.EnPassantCapture != null)
                g.SetBackground(ConsoleColor.DarkMagenta, 10 + board.EnPassantCapture.X, 5 + (7 - board.EnPassantCapture.Y));*//*

            //Lighten for checkerboard pattern
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if ((i + j) % 2 == 1) g.LightenBackground(10 + i, 5 + j);
                }
            }

            //Promotion option menu

            if (playerState == PlayerState.AwaitPromote)
            {
                g.DrawTextTrasparent("Queen", promoteOption == PromoteOptions.Queen ? ConsoleColor.Yellow : ConsoleColor.White, 22, 7);
                g.DrawTextTrasparent("Rook", promoteOption == PromoteOptions.Rook ? ConsoleColor.Yellow : ConsoleColor.White, 22, 9);
                g.DrawTextTrasparent("Bishop", promoteOption == PromoteOptions.Bishop ? ConsoleColor.Yellow : ConsoleColor.White, 22, 11);
                g.DrawTextTrasparent("Knight", promoteOption == PromoteOptions.Knight ? ConsoleColor.Yellow : ConsoleColor.White, 22, 13);
            }
            else
            {
                g.ClearArea(22, 7, 6, 7);
            }*/
            string s = "";
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    ChessBoard.Cell c = board.GetCell(i, j);
                    if (c.Piece != null)
                    {
                        /*if (count != 0)
                        {
                            s+= count.ToString();
                            count = 0;
                        }*/
                        char temp = c.Piece.Char;
                        temp = c.Piece.Color == PlayerColor.White ? char.ToUpper(temp) : char.ToLower(temp);
                        s += temp;
                    }
                    else
                    {
                        s += 'n';
                    }
                }
            }
            s += " ";
            if (holdedNode != null && playerState == PlayerState.Holding)
            {
                //Highlight legal moves
                foreach (ChessBoard.Cell move in holdedNode.Piece.LegalMoves)
                {
                    s += move.X.ToString() + move.Y + "/";
                }
            }
            return s;
        }
        public bool IsGameOver => playerState == PlayerState.GameOver;
        public bool InCheck => board.IsInCheck(currentPlayer);
        public PlayerColor CurrentPlayer => currentPlayer;
        public PlayerColor Winner => InCheck ? (currentPlayer == PlayerColor.White ? PlayerColor.Black : PlayerColor.White) : PlayerColor.Spectator;

        public void UpdateColor(int boja)
        {
            if (boja == 0)
                mojaboja = PlayerColor.White;
            else if (boja == 1)
                mojaboja = PlayerColor.Black;
        }

        #endregion

        #region EventHandlerLikeMethods

        /// <summary>
        /// Happens when the user presses the enter key / clicks a tile
        /// </summary>
        private string interact()
        {
            switch (playerState)
            {
                case PlayerState.Idle:
                    holdedNode = board.GetCell(cursorX, cursorY);

                    if (holdedNode == null || holdedNode.Piece == null || holdedNode.Piece.Color != currentPlayer || holdedNode.Piece.LegalMoves.Count == 0)
                    {
                        holdedNode = null;
                        return null;
                    }
                    if (mojaboja != PlayerColor.Spectator && currentPlayer != mojaboja)
                    {
                        holdedNode = null;
                        return null;
                    }
                    playerState = PlayerState.Holding;
                    break;

                case PlayerState.Holding:
                    moveTo = board.GetCell(cursorX, cursorY);
                    if (moveTo == null || holdedNode == null || holdedNode.Piece == null)
                    {
                        moveTo = null;
                        holdedNode = null;
                        playerState = PlayerState.Idle;
                        return null;
                    }

                    if (moveTo == holdedNode)
                    {
                        moveTo = null;
                        holdedNode = null;
                        playerState = PlayerState.Idle;
                        return null;
                    }

                    if (!holdedNode.Piece.LegalMoves.Contains(moveTo))
                    {
                        if (moveTo.Piece != null && moveTo.Piece.Color == currentPlayer && moveTo.Piece.LegalMoves.Count > 0)
                        {
                            holdedNode = moveTo;
                            moveTo = null;
                            return null;
                        }
                        moveTo = null;
                        holdedNode = null;
                        playerState = PlayerState.Idle;
                        return null;
                    }

                    if (board.IsPromotable(holdedNode, moveTo))
                    {
                        showPromote();
                        return turnOver();
                    }
                    else
                    {
                        return turnOver();
                    }

                case PlayerState.AwaitPromote:
                    return turnOver();

                case PlayerState.GameOver:
                    Running = false;
                    break;
            }
            return null;
        }


        private Piece debugPiece;
        private void debugInteract()
        {
            debugPiece = board.GetCell(cursorX, cursorY).Piece;
        }

        /// <summary>
        /// Cancels currently held piece selection
        /// </summary>
        public void Cancel()
        {
            playerState = PlayerState.Idle;
            holdedNode = null;
            moveTo = null;
        }

        #endregion

        #region EventLikeMethods
        /// <summary>
        /// Called on every turn start
        /// </summary>
        private void turnStart()
        {
            bool anyMove = board.TurnStart(currentPlayer);
            if (!anyMove)
            {
                playerState = PlayerState.GameOver;
            }
        }

        /// <summary>
        /// Shows promotion dialog (set's the state)
        /// </summary>
        private void showPromote()
        {
            playerState = PlayerState.AwaitPromote;
            promoteOption = PromoteOptions.Queen; //reset the menu
        }

        /// <summary>
        /// Called when the turn is passed to the other player
        /// </summary>
        private string turnOver()
        {
            if (holdedNode == null || moveTo == null)
            {
                playerState = PlayerState.Idle;
                return null;
            }
            string s = holdedNode.X + " " + holdedNode.Y + " " + moveTo.X + " " + moveTo.Y;
            board.Move(holdedNode, moveTo, promoteOption);
            holdedNode = null;
            moveTo = null;
            playerState = PlayerState.Idle;
            currentPlayer = currentPlayer == PlayerColor.White ? PlayerColor.Black : PlayerColor.White;
            turnStart();
            return s;
        }

        public void turnOver(int x, int y, int x1, int y1)
        {
            holdedNode = board.GetCell(x, y);
            moveTo = board.GetCell(x1, y1);
            if (holdedNode == null || moveTo == null) return;
            PromoteOptions opt = promoteOption;
            if (board.IsPromotable(holdedNode, moveTo))
                opt = PromoteOptions.Queen;
            board.Move(holdedNode, moveTo, opt);
            holdedNode = null;
            moveTo = null;
            playerState = PlayerState.Idle;
            currentPlayer = currentPlayer == PlayerColor.White ? PlayerColor.Black : PlayerColor.White;
            turnStart();
        }
        #endregion
    }
}
