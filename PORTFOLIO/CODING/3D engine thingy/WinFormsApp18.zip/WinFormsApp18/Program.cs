using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace WinFormsApp1
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
            CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;

            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        public static List<float> izdvojBrojeve(string s)
        {
            List<float> brojevi = new List<float>();
            bool pisemBrojeve = false;
            string sb = "";
            foreach (char c in s)
            {
                if (Char.IsDigit(c) || c == '.' || c == '-')
                {
                    if (!pisemBrojeve)
                    {
                        pisemBrojeve = true;
                    }
                    sb += c;
                }
                else if (pisemBrojeve)
                {
                    pisemBrojeve = false;
                    if (float.TryParse(sb, NumberStyles.Float, CultureInfo.InvariantCulture, out float val))
                        brojevi.Add(val);
                    sb = "";
                }
            }
            if (sb.Length > 0)
            {
                if (float.TryParse(sb, NumberStyles.Float, CultureInfo.InvariantCulture, out float val))
                    brojevi.Add(val);
            }
            return brojevi;
        }

    }
}
